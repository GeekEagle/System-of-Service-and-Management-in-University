package com.iflytek.voicecloud.webapi.demo.course;

/*import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTable;

public class MainFrame extends JFrame{
    public MainFrame() {
        this.setSize(1000,800);
        this.setTitle("欢迎使用教务处管理系统");
        Container pane=this.getContentPane();
        pane.setLayout(new FlowLayout(FlowLayout.LEFT));

        JTable table=new JTable();
        pane.add(table);

        //学籍录入功能
        JButton btnAdd=new JButton("学籍录入");
        pane.add(btnAdd);
        setLayout( null );
        btnAdd.setBounds(100,80,100,80);
        btnAdd.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                EntryFrame f =new EntryFrame();
                f.setVisible(true);
            }
        });

        //成绩统计排名功能
        JButton btnAdd2=new JButton("成绩统计");
        pane.add(btnAdd2);
        btnAdd2.setBounds(200,80,100,80);
        btnAdd2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                CountFrame f =new CountFrame();
                f.setVisible(true);
            }
        });

        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    public static void main(String[] args) {
        MainFrame f = new MainFrame();
        f.setVisible(true);
    }
}*/





